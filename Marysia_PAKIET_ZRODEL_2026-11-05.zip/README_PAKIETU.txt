DRZEWO GENEALOGICZNE MARYSI — PACZKA PRZEKAZANIA
Stan materiałów: 5 listopada 2026 r.

ZACZNIJ TUTAJ:
1. Marysia_INSTRUKCJA_DLA_AGENTA.md — samodzielne szczegółowe opracowanie:
   56 źródeł z dokładnymi URL, 28 zdarzeń, 24 kandydatów/homonimów,
   24 ostrzeżenia/korekty oraz 28 następnych działań.
2. Marysia_KOMPLET_BAZA_2026-11-05.xlsx — KANONICZNA BAZA,
   16 arkuszy, każdy fakt z oceną i identyfikatorem źródła; przegląd
   rozpocznij od zakładki START oraz POTWIERDZONE_AKTEM_1936.
3. Marysia_Zrodla/ — pełny skan małżeństwa 1936,
   skany z indeksu USC 1943, oryginalne 3 zdjęcia grobu Tomasza,
   dodatkowe kadry skanu dla czytelności.
4. raport_z_poprzedniej_sesji/Marysia_raport_2026-11-05.html
   — zachowana starsza analiza (może zawierać niepełne hipotezy).
5. archiwum_wersji_Excel/ — NIEWAŻNE historyczne wersje robocze,
   służą tylko kontroli, czy czegoś nie przeoczono.

NIE WOLNO:
* utożsamiać w pełni policjanta Piotra Chmielewskiego z Łodzi
  z kuzynem Marysi — brak dowodu łączącego ich;
* twierdzić, że akt małżeństwa 1936 sam dowodzi pochodzenia Bogusława;
* zastępować pewnego adresu Stocka 12 niepotwierdzonym Przyborowskiego 8;
* utrzymywać, że skorowidz 1943ax obejmuje cały rok 1943;
* wysyłać wniosków/emaili, płacić lub publikować danych osób żyjących
  bez wyraźnej zgody użytkownika;
* szukać ponownie znanego grobu Tomasza.

DATA I WERYFIKACJA:
Źródła w arkuszu zawierają rozróżnienie:
- „ODCZYTANO OBRAZ” — skan przeczytany;
- „INDEKS” — pełny akt wymaga odnalezienia;
- „KATALOG” — nie dowodzi treści akt;
- „RELACJA RODZINNA” — przekaz, nie urzędowe potwierdzenie.

Opracowanie jest maksymalnie kompletne w granicach dostępnych materiałów.
Nie stanowi gwarancji, że każda wypowiedź ze wszystkich rozmów historycznych
jest odzyskiwalna; niezależne luki są opisane w workbooku.
